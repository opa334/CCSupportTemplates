#import "CCSModuleProvider.h"

@interface @@PROJECTNAME@@ : NSObject <CCSModuleProvider>

@end
