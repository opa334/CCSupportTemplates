#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import "CCSModuleProvider.h"

@interface @@PROJECTNAME@@ : NSObject <CCSModuleProvider>

@end
